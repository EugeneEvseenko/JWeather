<?php 
	$loc = $_REQUEST["page-nav"];
	header("Location: $loc"); 
?>